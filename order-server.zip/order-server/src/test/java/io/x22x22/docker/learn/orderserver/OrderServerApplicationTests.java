package io.x22x22.docker.learn.orderserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

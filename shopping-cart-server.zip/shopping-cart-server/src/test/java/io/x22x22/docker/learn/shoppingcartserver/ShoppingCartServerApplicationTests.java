package io.x22x22.docker.learn.shoppingcartserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
